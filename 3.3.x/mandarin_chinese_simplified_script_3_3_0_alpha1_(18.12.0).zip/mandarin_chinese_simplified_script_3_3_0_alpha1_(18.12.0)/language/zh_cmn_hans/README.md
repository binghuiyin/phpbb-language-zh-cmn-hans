phpBB Mandarin Chinese Simplified Language Pack v18.12.0
for phpBB 3.3.0 alpha 1 Dev

*** TABLE OF CONTENT ***
AUTHORS
CHANGELOG
DOWNLOAD AND INSTALL


*** DETAILS ***

AUTHORS
David Yin @binghuiyin (twitter) Since 2015.10
Thanks to yoshika, rexkyo, wang5555, tabwe

CHANGELOG
Version 18.12.0
* Made the first version for phpBB 3.3.0 Alpha


DOWNLOAD AND INSTALL
* The latest version can be downloaded here
https://www.phpbbchinese.com/viewforum.php?f=28




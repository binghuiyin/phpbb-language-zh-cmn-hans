<?php
/**
*
* This file is part of the phpBB Forum Software package.
* @简体中文语言　David Yin <https://www.phpbbchinese.com/>
* @copyright (c) phpBB Limited <https://www.phpbb.com>
* @license GNU General Public License, version 2 (GPL-2.0)
*
* For full copyright and license information, please see
* the docs/CREDITS.txt file.
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(

	// Template
	'STORAGE_TITLE'					=> '存储设定',
	'STORAGE_TITLE_EXPLAIN'			=> '为 phpBB 的文件存储类型而修改提供存储的服务商。给添加到 phpBB 的文件或者 phpBB 自己生成的文件选择本地或者远程服务商。',
	'STORAGE_SELECT'				=> '选择存储',
	'STORAGE_SELECT_DESC'			=> '从列表中选择一个存储',
	'STORAGE_NAME'					=> '存储名称',
	'STORAGE_NUM_FILES'				=> '文件数目',
	'STORAGE_SIZE'					=> '大小',
	'STORAGE_FREE'					=> '可用空间',
	'STORAGE_UNKNOWN'				=> '未知',

	// Storage names
	'STORAGE_ATTACHMENT_TITLE'		=> '附件存储',
	'STORAGE_AVATAR_TITLE'			=> '头像存储',
	'STORAGE_BACKUP_TITLE'			=> '备份存储',

	// Local adapter
	'STORAGE_ADAPTER_LOCAL_NAME'						=> '本地',
	'STORAGE_ADAPTER_LOCAL_OPTION_PATH'					=> '路径',
	'STORAGE_ADAPTER_LOCAL_OPTION_SUBFOLDERS'			=> '用子目录来组织',
	'STORAGE_ADAPTER_LOCAL_OPTION_SUBFOLDERS_EXPLAIN'	=> '某些 Web 服务器在单一目录下储存大量数目的文件会出现问题。启用此选项可以把文件放在不同的目录之下。',

	// Form validation
	'STORAGE_UPDATE_SUCCESSFUL' 				=>	'所有的存储类型都成功更新了。',
	'STORAGE_NO_CHANGES'						=>	'没有改变。',
	'STORAGE_PROVIDER_NOT_EXISTS'				=>	'为 %s 选择的服务商不存在。',
	'STORAGE_PROVIDER_NOT_AVAILABLE'			=>	'为 %s 选择的服务商不可用。',
	'STORAGE_FORM_TYPE_EMAIL_INCORRECT_FORMAT'	=>	'电子邮件不正确 %s 的 %s。',
	'STORAGE_FORM_TYPE_TEXT_TOO_LONG'			=>	'文本太长 %s 的 %s。',
	'STORAGE_FORM_TYPE_SELECT_NOT_AVAILABLE'	=>	'选择的值不可用 %s 的 %s。',
));

phpBB Mandarin Chinese Simplified Language Pack v20.01.0
for phpBB 3.2.9

*** TABLE OF CONTENT ***
AUTHORS
CHANGELOG
DOWNLOAD AND INSTALL


*** DETAILS ***

AUTHORS
David Yin @binghuiyin (twitter) Since 2015.10
Thanks to yoshika, rexkyo, wang5555, tabwe

CHANGELOG

Version 20.01.0
* Upgrade with phpBB 3.2.9

Version 19.09.0
* Upgrade with phpBB 3.2.8

Version 19.05.0
* Bump the version number only, no changes of language pack


Version 19.04.0
* Upgrade with phpBB 3.2.6

Version 18.12.0
* Upgrade with phpBB 3.2.5

Version 18.11.2
* Fix some translation in ACP.
* Add Chinese fonts into prosilver theme

Version 18.11.1
* Modified some translation to make it more accurate.

Version 18.11.0
* Upgrade with phpBB 3.2.4

Version 18.09.1
* Change Plural Rules from 1 to 0, it is for Chinese Language.
* Change all related plural array based on the rule 0.

Version 18.09.0
* Upgrade with phpBB 3.2.3

Version 18.04.0
* Add the translation to test email template
* Correct the iso.txt format

Version 18.03.0
* Fix the errors of translation

Version 18.01.0
* Upgrade with phpBB 3.2.2

Version 17.07.0
2017.07.18
* Update with phpBB 3.2.1
* Update related VigLink extension translation

Version 17.01.0
2017.01.1
* Update with phpBB  3.2.0

Version 16.12.0.RC2
2016.12.12
* Update with phpBB  3.2.0 RC2

Version 16.6.0.RC1
2016.6.12
* Update with phpBB  3.2.0 RC1

Version 16.6.0.b2
2016.12
* Update with phpBB 3.2.0 Beta 2

Version 16.6.0.b1
2016.6.12
* Update with phpBB 3.2.0 beta 1

Version 16.6.0.a2
2016.6.11
* Update with phpBB 3.2.0 alphpa 2
* Change last version number from 16.6.0 to 16.6.0.a1

Version 16.6.0.a1
2016.06.10
* Made the first version for phpBB 3.2.0 Alpha1




DOWNLOAD AND INSTALL
* The latest version can be downloaded here
https://www.phpbbchinese.com/viewforum.php?f=28




<?php
/**
*
* This file is part of the phpBB Forum Software package.
* @简体中文语言　David Yin <https://www.phpbbchinese.com/>
* @copyright (c) phpBB Limited <https://www.phpbb.com>
* @license GNU General Public License, version 2 (GPL-2.0)
*
* For full copyright and license information, please see
* the docs/CREDITS.txt file.
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

/**
* DO NOT CHANGE
*/
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(

	'EXTENSIONS_ALREADY_INSTALLED'				=> '扩展 “%s” 已经安装过了。',
	'EXTENSIONS_ALREADY_INSTALLED_MANUALLY'		=> '扩展 “%s” 已经手工安装过了。',
	'EXTENSIONS_ALREADY_MANAGED'					=> '扩展 “%s” 已被管理。',
	'EXTENSIONS_CANNOT_MANAGE_FILESYSTEM_ERROR'	=> '扩展 “%s” 无法被管理，因为其现存的文件无法从文件系统中被删除。',
	'EXTENSIONS_CANNOT_MANAGE_INSTALL_ERROR'		=> '扩展 “%s” 无法被安装，其之前的安装已经被恢复。',
	'EXTENSIONS_MANAGED_WITH_CLEAN_ERROR'		=> '扩展 “%1$s” 已被安装，但是发生一个错误，旧文件无法被删除，您也许可以考虑手动删除文件 “%2$s” 。',
	'EXTENSIONS_MANAGED_WITH_ENABLE_ERROR'		=> '扩展 “%s” 已被安装，但是在启用时发生一个错误。',
	'EXTENSIONS_NOT_INSTALLED'					=> '扩展 “%s” 没有被安装。',
	'EXTENSIONS_NOT_MANAGED'					=> '扩展 “%s” 无法被管理。',

	'ENABLING_EXTENSIONS'	=> '启用扩展',
	'DISABLING_EXTENSIONS'	=> '停用扩展',

	'EXTENSIONS_CATALOG'			=> '扩展库',
	'EXTENSIONS_CATALOG_EXPLAIN'	=> '这里您可以浏览所有可以应用在你的 phpBB 论坛中的扩展。您可以非常简便的一键安装，或者一键删除扩展。调整设定可使扩展安装后即刻启用，或者停用后马上删除。',

	'EXTENSION'					=> '扩展',
	'EXTENSIONS'				=> '扩展',
	'EXTENSIONS_ADMIN'			=> '扩展管理器',
	'EXTENSIONS_EXPLAIN'		=> '扩展管理器是 phpBB 论坛的一个工具，允许您管理所有扩展的状态和查看有关信息。',
	'EXTENSION_INVALID_LIST'	=> '扩展 “%s” 不可用。<br />%s<br /><br />',
	'EXTENSION_NOT_AVAILABLE'	=> '所选扩展对当前论坛不可用，请验证 phpBB 和 PHP 版本是否允许(看详情页)。',
	'EXTENSION_DIR_INVALID'		=> '所选扩展有一个无效目录结构，所以无法启用。',
	'EXTENSION_NOT_ENABLEABLE'	=> '所选扩展不能启用，请验证扩展的安装要求。',

	'DETAILS'				=> '详情',

	'EXTENSIONS_AVAILABLE'	=> '可用的扩展',
	'EXTENSIONS_DISABLED'	=> '停用的扩展',
	'EXTENSIONS_ENABLED'	=> '启用的扩展',

	'EXTENSION_DELETE_DATA'	=> '删除数据',
	'EXTENSION_DISABLE'		=> '停用',
	'EXTENSION_ENABLE'		=> '启用',
	'EXTENSION_UPDATE'		=> '更新',
	'EXTENSION_REMOVE'		=> '删除',


	'EXTENSION_DELETE_DATA_EXPLAIN'	=> '删除扩展数据将移除所有数据和设置，扩展文件仍然保留以后可以重启。',
	'EXTENSION_DISABLE_EXPLAIN'		=> '停用扩展将保留文件、数据和设置但其功能失效。',
	'EXTENSION_ENABLE_EXPLAIN'		=> '启用扩展允许您在论坛上使用它。',
	'EXTENSION_REMOVE_EXPLAIN'		=> '删除扩展将删除其所有的文件数据和设置。',
	'EXTENSION_UPDATE_EXPLAIN'		=> '更新一个扩展将安装最新的兼容您论坛的版本，删除旧有的文件和替换新的文件，以及更新数据库。',
	
	'EXTENSION_DELETE_DATA_IN_PROGRESS'	=> '扩展数据正在删除，完成前请不要关闭或刷新此页。',
	'EXTENSION_DISABLE_IN_PROGRESS'	=> '扩展正在停用，完成前请不要关闭或刷新此页。',
	'EXTENSION_ENABLE_IN_PROGRESS'	=> '扩展正在启用，完成前请不要关闭或刷新此页。',

	'EXTENSION_DELETE_DATA_SUCCESS'	=> '扩展数据删除成功',
	'EXTENSION_DISABLE_SUCCESS'		=> '扩展停用成功',
	'EXTENSION_ENABLE_SUCCESS'		=> '扩展启用成功',

	'EXTENSION_NAME'			=> '扩展名称',
	'EXTENSION_ACTIONS'			=> '操作',
	'EXTENSION_OPTIONS'			=> '选项',
	'EXTENSION_INSTALLING_HEADLINE'=> '安装扩展功能',
	'EXTENSION_INSTALLING_EXPLAIN'	=> [
		0 => '从 phpBB 的扩展数据库中下载',
		1 => '解压缩，并上传到您的 phpBB 论坛的 <samp>ext/</samp> 文件夹',
		2 => '在扩展管理器中启用它',
	],
	'EXTENSION_REMOVING_HEADLINE'	=> '删除一个扩展',
	'EXTENSION_REMOVING_EXPLAIN'	=> [
		0 => '停用扩展',
		1 => '删除扩展数据',
		2 => '删除扩展文件',
	],
	'EXTENSION_UPDATING_HEADLINE'	=> '更新一个扩展',
	'EXTENSION_UPDATING_EXPLAIN'	=> [
		0 => '停用扩展',
		1 => '删除原扩展文件',
		2 => '上传新文件',
		3 => '启用扩展',
	],
	
	'EXTENSION_DELETE_DATA_CONFIRM'	=> '您确定要删除有关 “%s” 的数据吗？<br /><br />这将删除它的所有数据和设置而且不能恢复！',
	'EXTENSION_DISABLE_CONFIRM'		=> '您确定要停用 “%s” 扩展吗？',
	'EXTENSION_ENABLE_CONFIRM'		=> '您确定要启用 “%s” 扩展吗？',
	'EXTENSION_FORCE_UNSTABLE_CONFIRM'	=> '您确定要强制使用非稳定的版本吗？',

	'INSTALLED'				=> '已安装',
	'INSTALLED_MANUALLY'	=> '已手动安装',

	'RETURN_TO_EXTENSION_LIST'	=> '返回扩展列表',

	'EXT_DETAILS'			=> '扩展详情',
	'DISPLAY_NAME'			=> '显示名称',
	'CLEAN_NAME'			=> '名称',
	'TYPE'					=> '类型',
	'DESCRIPTION'			=> '描述',
	'VERSION'				=> '版本',
	'HOMEPAGE'				=> '主页',
	'PATH'					=> '文件路径',
	'TIME'					=> '发布时间',
	'LICENSE'				=> '许可',

	'REQUIREMENTS'			=> '要求',
	'PHPBB_VERSION'			=> 'phpBB 版本',
	'PHP_VERSION'			=> 'PHP 版本',
	'AUTHOR_INFORMATION'	=> '作者信息',
	'AUTHOR_NAME'			=> '名称',
	'AUTHOR_EMAIL'			=> 'Email',
	'AUTHOR_HOMEPAGE'		=> '主页',
	'AUTHOR_ROLE'			=> '角色',

	'NOT_UP_TO_DATE'		=> '%s 不是最新的版本',
	'UP_TO_DATE'			=> '%s 是最新的版本',
	'ANNOUNCEMENT_TOPIC'	=> '发布公告',
	'DOWNLOAD_LATEST'		=> '下载版本',
	'NO_VERSIONCHECK'		=> '没有提供版本检查信息。',

	'VERSIONCHECK_FORCE_UPDATE_ALL'		=> '重新检查所有版本',
	'FORCE_UNSTABLE'					=> '总是检查非稳定的版本',
	'EXTENSIONS_VERSION_CHECK_SETTINGS'	=> '版本检查设置',

	'BROWSE_EXTENSIONS_DATABASE'		=> '浏览扩展数据库',

	'META_FIELD_NOT_SET'	=> '所需的元字段 %s 还没有设置。',
	'META_FIELD_INVALID'	=> '元字段 %s 无效。',
	
	'EXTENSIONS_CATALOG_SETTINGS'	=> '扩展库设定',
	'ENABLE_ON_INSTALL'				=> '安装扩展并启用',
	'PURGE_ON_REMOVE'				=> '停用扩展并删除',
	'ENABLE_PACKAGIST'				=> '搜索安装包',
	'ENABLE_PACKAGIST_EXPLAIN'		=> '搜索 packagist。注意 packagist 也许会包含未被 phpBB 扩展定制团队验证的扩展。',
	'ENABLE_PACKAGIST_CONFIRM'		=> '您确定要搜索 packagist 吗？',
	'COMPOSER_REPOSITORIES'			=> '软件包仓库',
	'COMPOSER_REPOSITORIES_EXPLAIN'	=> '添加网址到用于搜索 phpBB 扩展的 Composer 软件仓库。每行一个（必须是 packages.json 文件的 base url。） ',
	'NO_EXTENSION_AVAILABLE'		=> '没有可用于您的论坛的扩展。',

	'EXTENSION_MANAGED_SUCCESS'		=> '扩展 %s 现在是自动管理的。',
	'EXTENSIONS_INSTALLED'			=> '扩展安装成功。',
	'EXTENSIONS_REMOVED'			=> '扩展删除成功。',
	'EXTENSIONS_UPDATED'			=> '扩展更新成功。',

	'EXTENSIONS_CATALOG_NOT_AVAILABLE'	=> '扩展库不可用。',
	'EXTENSIONS_COMPOSER_NOT_WRITABLE'	=> '要使用扩展库，下列文件和目录必须可写入： ext/ vendor-ext/ composer-ext.json 和 composer-ext.lock',

	'STABILITY_STABLE'	=> '（稳定版）stable',
	'STABILITY_RC'		=> '（发布候选版本）RC',
	'STABILITY_BETA'	=> '（公测版）beta',
	'STABILITY_ALPHA'	=> '（内测版）alpha',
	'STABILITY_DEV'		=> '（开发版本）dev',

	'COMPOSER_MINIMUM_STABILITY'			=> '最低稳定性',
	'COMPOSER_MINIMUM_STABILITY_EXPLAIN'	=> '在活跃论坛总是使用 <samp>（稳定版）stable</samp> 。 非稳定版本也许仍在开发阶段，可能会导致不可预测的问题，所以应该只在本地，或者临时环境下，基于开发的目的下使用。',

));

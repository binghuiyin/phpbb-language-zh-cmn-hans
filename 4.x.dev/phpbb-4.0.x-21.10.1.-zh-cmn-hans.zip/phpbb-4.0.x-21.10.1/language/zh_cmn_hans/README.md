phpBB Mandarin Chinese Simplified Language Pack 
for phpBB 4.4.0 Dev

*** TABLE OF CONTENT ***
AUTHORS
CHANGELOG
DOWNLOAD AND INSTALL


*** DETAILS ***

AUTHORS
David Yin @binghuiyin (twitter) Since 2015.10
Thanks to yoshika, rexkyo, wang5555, tabwe

CHANGELOG
Based on the master branch of phpBB github source code
* Made the first version for phpBB 4.4.0


DOWNLOAD AND INSTALL
* The latest version can be downloaded here
https://www.phpbbchinese.com/viewforum.php?f=28



